/**
 * Classes for creating dial plots.
 */
package org.jfree.chart.plot.dial;
