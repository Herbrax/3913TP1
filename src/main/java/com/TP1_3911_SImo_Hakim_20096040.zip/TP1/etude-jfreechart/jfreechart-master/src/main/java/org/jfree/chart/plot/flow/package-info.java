/**
 * Classes for creating flow plots (a type of Sankey chart).
 */
package org.jfree.chart.plot.flow;
